const TelegramBot = require("node-telegram-bot-api");
const axios = require("axios");
const fs = require("fs");
const path = require("path");

// Load config
const configPath = "./config.json";
const config = JSON.parse(fs.readFileSync(configPath, "utf-8"));

let BOT_TOKEN = config.BOT_TOKEN;
let GITHUB_TOKEN = config.GITHUB_TOKEN;
const GITHUB_API_URL = `https://api.github.com/repos/${config.REPO_OWNER}/${config.REPO_NAME}/contents/${config.FILE_PATH}`;
let OWNER_ID = config.OWNER_ID || [8694518121];

const bot = new TelegramBot(BOT_TOKEN, { polling: true });
const usersFile = path.join(__dirname, "users.json");
const pendingActions = {};

console.log("Bot jalan...");

// Fungsi simpan config
function saveConfig() {
  config.OWNER_ID = OWNER_ID;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
}

function isOwner(userId) {
  return OWNER_ID.includes(userId);
}

async function getTokens() {
  try {
    const res = await axios.get(GITHUB_API_URL, {
      headers: {
        Authorization: `token ${GITHUB_TOKEN}`,
        Accept: "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28"
      }
    });
    const content = Buffer.from(res.data.content, "base64").toString("utf-8");
    const json = JSON.parse(content);
    return { tokens: json.valid_tokens || [], sha: res.data.sha };
  } catch (err) {
    console.log("Error getTokens:", err.response?.data?.message || err.message);
    return { tokens: [], sha: null };
  }
}

async function saveTokens(tokens, sha) {
  try {
    const content = Buffer.from(JSON.stringify({ valid_tokens: tokens }, null, 2)).toString("base64");
    const res = await axios.put(
      GITHUB_API_URL,
      {
        message: "Update valid_tokens via Telegram bot",
        content: content,
      ...(sha && { sha })
      },
      {
        headers: {
          Authorization: `token ${GITHUB_TOKEN}`,
          Accept: "application/vnd.github+json",
          "X-GitHub-Api-Version": "2022-11-28"
        }
      }
    );
    return res.data;
  } catch (err) {
    console.log("Error saveTokens:", err.response?.data?.message || err.message);
    throw err;
  }
}

function getBotRuntime() {
  let uptime = process.uptime();
  let h = Math.floor(uptime / 3600);
  let m = Math.floor((uptime % 3600) / 60);
  let s = Math.floor(uptime % 60);
  return `${h}h ${m}m ${s}s`;
}

function getVideo() {
  return "https://files.catbox.moe/r3xvuo.mp4";
}

// Auto save user ID + handler reply force_reply
bot.on("message", async (msg) => {
  if (!msg.from || msg.from.is_bot) return;

  if (!msg.text?.startsWith("/")) {
    let users = [];
    if (fs.existsSync(usersFile)) {
      users = JSON.parse(fs.readFileSync(usersFile));
    }
    if (!users.includes(msg.chat.id)) {
      users.push(msg.chat.id);
      fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
    }
  }

  if (msg.reply_to_message && msg.reply_to_message.from.is_bot) {
    const chatId = msg.chat.id;
    const actionData = pendingActions[chatId];
    if (!actionData) return;

    const input = msg.text.trim();
    delete pendingActions[chatId];

    if (actionData.action === "addowner") {
      const newOwnerId = parseInt(input);
      if (isNaN(newOwnerId)) {
        return bot.sendMessage(chatId, "❌ ID harus angka!", { reply_to_message_id: msg.message_id });
      }
      if (OWNER_ID.includes(newOwnerId)) {
        return bot.sendMessage(chatId, "⚠️ User itu udah jadi owner!", { reply_to_message_id: msg.message_id });
      }

      OWNER_ID.push(newOwnerId);
      saveConfig();
      bot.sendMessage(chatId, `✅ User <code>${newOwnerId}</code> berhasil ditambah jadi owner!`, {
        parse_mode: "HTML",
        reply_to_message_id: msg.message_id
      });
      return;
    }

    if (actionData.action === "delowner") {
      const delOwnerId = parseInt(input);
      if (isNaN(delOwnerId)) {
        return bot.sendMessage(chatId, "❌ ID harus angka!", { reply_to_message_id: msg.message_id });
      }
      if (!OWNER_ID.includes(delOwnerId)) {
        return bot.sendMessage(chatId, "⚠️ User itu bukan owner!", { reply_to_message_id: msg.message_id });
      }
      if (OWNER_ID.length === 1) {
        return bot.sendMessage(chatId, "❌ Gak bisa hapus owner terakhir!", { reply_to_message_id: msg.message_id });
      }

      OWNER_ID = OWNER_ID.filter(id => id!== delOwnerId);
      saveConfig();
      bot.sendMessage(chatId, `✅ User <code>${delOwnerId}</code> berhasil dihapus dari owner!`, {
        parse_mode: "HTML",
        reply_to_message_id: msg.message_id
      });
      return;
    }

    const token = input;
    const { tokens, sha } = await getTokens();

    if (actionData.action === "addtoken") {
      if (tokens.includes(token)) {
        return bot.sendMessage(chatId, "⚠️ Token udah ada!", { reply_to_message_id: msg.message_id });
      }
      tokens.push(token);
      try {
        await saveTokens(tokens, sha);
        bot.sendMessage(chatId, `✅ Token berhasil ditambah:\n<code>${token}</code>`, {
          parse_mode: "HTML",
          reply_to_message_id: msg.message_id
        });
      } catch (err) {
        bot.sendMessage(chatId, `❌ Gagal add token: ${err.response?.data?.message || err.message}`, {
          reply_to_message_id: msg.message_id
        });
      }
    }

    if (actionData.action === "deltoken") {
      if (!tokens.includes(token)) {
        return bot.sendMessage(chatId, "⚠️ Token nggak ada di list!", { reply_to_message_id: msg.message_id });
      }
      const newTokens = tokens.filter(t => t!== token);
      try {
        await saveTokens(newTokens, sha);
        bot.sendMessage(chatId, `✅ Token berhasil dihapus:\n<code>${token}</code>`, {
          parse_mode: "HTML",
          reply_to_message_id: msg.message_id
        });
      } catch (err) {
        bot.sendMessage(chatId, `❌ Gagal hapus token: ${err.response?.data?.message || err.message}`, {
          reply_to_message_id: msg.message_id
        });
      }
    }
  }
});

// Handler /start
bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const username = msg.from.username? `@${msg.from.username}` : "Tidak ada username";

  const runtime = getBotRuntime();
  const caption = `<blockquote>
┏━✧「 INFORMASI 」✧━⬣
┃ 𒆜 BotName : Token Manager Bot
┃ 𒆜 Version : 1.0
┃ 𒆜 Owner Count : ${OWNER_ID.length}
┗━━━━━━━━⬣
┏━✧「 STATUS 」✧━⬣
┃ ✧ Name : ${username}
┃ ✧ Runtime : ${runtime}
┃ ✧ UserId : ${senderId}
┗━━━━━━━━━━━━━━⬣ </blockquote>`;

  try {
    await bot.sendVideo(chatId, getVideo(), {
      caption: caption,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: [[{ text: "🔥 Menu", callback_data: "open_menu" }]] }
    });
  } catch (err) {
    bot.sendMessage(chatId, "Gagal kirim video. Error: " + err.message);
  }
});

// Handler menu
function sendMenu(chatId) {
  const menuText = `<blockquote>🛠️ TOKEN MANAGER MENU</blockquote>
Pilih menu di bawah ini:`;

  const keyboard = {
    inline_keyboard: [
      [
        { text: "➕ Add Token", callback_data: "cmd_add" },
        { text: "📜 List Token", callback_data: "cmd_list" },
        { text: "🗑️ Del Token", callback_data: "cmd_del" }
      ],
      [
        { text: "👑 Add Owner", callback_data: "cmd_addowner" },
        { text: "❌ Del Owner", callback_data: "cmd_delowner" }
      ],
      [{ text: "⬅️ Kembali", callback_data: "back_start" }]
    ]
  };

  bot.sendMessage(chatId, menuText, {
    parse_mode: "HTML",
    reply_markup: keyboard
  });
}

bot.onText(/\/menu/, (msg) => {
  sendMenu(msg.chat.id);
});

// Handler tombol inline
bot.on("callback_query", async (callbackQuery) => {
  const msg = callbackQuery.message;
  const data = callbackQuery.data;
  const chatId = msg.chat.id;
  const from = callbackQuery.from;

  try { await bot.answerCallbackQuery(callbackQuery.id); } catch(e) {}

  switch (data) {
    case "open_menu":
      try { await bot.deleteMessage(chatId, msg.message_id); } catch(e) {}
      sendMenu(chatId);
      break;

    case "back_start":
      try { await bot.deleteMessage(chatId, msg.message_id); } catch(e) {}
      const username = from.username? `@${from.username}` : "Tidak ada username";
      const runtime = getBotRuntime();
      const caption = `<blockquote>
┏━✧「 INFORMASI 」✧━⬣
┃ 𒆜 BotName : Token Manager Bot
┃ 𒆜 Version : 1.0
┃ 𒆜 Owner Count : ${OWNER_ID.length}
┗━━━━━━━━⬣
┏━✧「 STATUS 」✧━⬣
┃ ✧ Name : ${username}
┃ ✧ Runtime : ${runtime}
┃ ✧ UserId : ${from.id}
┗━━━━━━━━━━━━━━⬣ </blockquote>`;

      await bot.sendVideo(chatId, getVideo(), {
        caption: caption,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "🔥 Menu", callback_data: "open_menu" }]] }
      });
      break;

    case "cmd_add":
      if (!isOwner(from.id)) return bot.sendMessage(chatId, "❌ Lu bukan owner!");
      pendingActions[chatId] = { action: "addtoken" };
      bot.sendMessage(chatId, "📩 Reply pesan ini dengan token yang mau ditambah:", {
        reply_markup: { force_reply: true, selective: true },
        parse_mode: "HTML"
      });
      break;

    case "cmd_list":
      if (!isOwner(from.id)) return bot.sendMessage(chatId, "❌ Lu bukan owner!");
      const { tokens } = await getTokens();
      if (tokens.length === 0) {
        bot.sendMessage(chatId, "Kosong bro, belum ada token di valid_tokens.");
      } else {
        bot.sendMessage(chatId, `📜 Daftar Token valid_tokens:\n\n<code>${tokens.join("</code>\n<code>")}</code>`, {
          parse_mode: "HTML"
        });
      }
      break;

    case "cmd_del":
      if (!isOwner(from.id)) return bot.sendMessage(chatId, "❌ Lu bukan owner!");
      pendingActions[chatId] = { action: "deltoken" };
      bot.sendMessage(chatId, "📩 Reply pesan ini dengan token yang mau dihapus:", {
        reply_markup: { force_reply: true, selective: true },
        parse_mode: "HTML"
      });
      break;

    case "cmd_addowner":
      if (!isOwner(from.id)) return bot.sendMessage(chatId, "❌ Lu bukan owner!");
      pendingActions[chatId] = { action: "addowner" };
      bot.sendMessage(chatId, "📩 Reply pesan ini dengan User ID yang mau dijadiin owner:", {
        reply_markup: { force_reply: true, selective: true },
        parse_mode: "HTML"
      });
      break;

    case "cmd_delowner":
      if (!isOwner(from.id)) return bot.sendMessage(chatId, "❌ Lu bukan owner!");
      if (OWNER_ID.length === 1) return bot.sendMessage(chatId, "❌ Gak bisa hapus owner terakhir!");
      pendingActions[chatId] = { action: "delowner" };
      bot.sendMessage(chatId, `📩 Reply pesan ini dengan User ID yang mau dihapus dari owner:\n\nOwner sekarang:\n<code>${OWNER_ID.join("</code>\n<code>")}</code>`, {
        reply_markup: { force_reply: true, selective: true },
        parse_mode: "HTML"
      });
      break;
  }
});

// Command /addowner langsung
bot.onText(/\/addowner (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!isOwner(userId)) return bot.sendMessage(chatId, "❌ Lu bukan owner!", { reply_to_message_id: msg.message_id });

  const newOwnerId = parseInt(match[1].trim());
  if (isNaN(newOwnerId)) return bot.sendMessage(chatId, "❌ ID harus angka!", { reply_to_message_id: msg.message_id });
  if (OWNER_ID.includes(newOwnerId)) return bot.sendMessage(chatId, "⚠️ User itu udah jadi owner!", { reply_to_message_id: msg.message_id });

  OWNER_ID.push(newOwnerId);
  saveConfig();
  bot.sendMessage(chatId, `✅ User <code>${newOwnerId}</code> berhasil ditambah jadi owner!`, {
    parse_mode: "HTML",
    reply_to_message_id: msg.message_id
  });
});

// Command /delowner langsung
bot.onText(/\/delowner (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!isOwner(userId)) return bot.sendMessage(chatId, "❌ Lu bukan owner!", { reply_to_message_id: msg.message_id });

  const delOwnerId = parseInt(match[1].trim());
  if (isNaN(delOwnerId)) return bot.sendMessage(chatId, "❌ ID harus angka!", { reply_to_message_id: msg.message_id });
  if (!OWNER_ID.includes(delOwnerId)) return bot.sendMessage(chatId, "⚠️ User itu bukan owner!", { reply_to_message_id: msg.message_id });
  if (OWNER_ID.length === 1) return bot.sendMessage(chatId, "❌ Gak bisa hapus owner terakhir!", { reply_to_message_id: msg.message_id });

  OWNER_ID = OWNER_ID.filter(id => id!== delOwnerId);
  saveConfig();
  bot.sendMessage(chatId, `✅ User <code>${delOwnerId}</code> berhasil dihapus dari owner!`, {
    parse_mode: "HTML",
    reply_to_message_id: msg.message_id
  });
});

bot.on("polling_error", err => console.log("Polling error:", err.message));

bot.setMyCommands([
  { command: 'start', description: '🏠 Mulai bot' },
  { command: 'menu', description: '📋 Buka menu' },
  { command: 'addowner', description: '👑 Tambah owner' },
  { command: 'delowner', description: '❌ Hapus owner' }
]).then(() => {
  console.log("Commands set!");
}).catch(err => {
  console.log("Gagal set commands:", err.message);
});