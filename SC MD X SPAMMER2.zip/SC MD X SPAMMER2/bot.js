const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    makeCacheableSignalKeyStore,
    fetchLatestBaileysVersion
} = require('@whiskeysockets/baileys');
const pino = require('pino');
const fs = require("fs");
const path = require("path");
const chalk = require("chalk");
const config = require("./config.js");
const axios = require("axios");
const TelegramBot = require("node-telegram-bot-api");

const BOT_TOKEN = config.BOT_TOKEN;
const OWNER_ID = config.OWNER_ID;
const TOKEN_URL = 'https://raw.githubusercontent.com/fathirmobilelegend-dotcom/Token-bot-Xterclose-md/refs/heads/main/token.json';
const dbFile = path.join(__dirname, "db.json");

// ========== VALIDASI TOKEN GITHUB ==========
async function fetchValidTokens() {
  try {
    const res = await axios.get(TOKEN_URL, {
      headers: {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
      }
    });
    const tokens = res.data.valid_tokens || [];
    console.log(chalk.blue(`[VALIDASI] Ditemukan ${tokens.length} token di GitHub`));
    return tokens;
  } catch (err) {
    console.log(chalk.red('❌ Error ambil token dari GitHub:', err.message));
    return [];
  }
}

async function validateToken(token) {
  const validTokens = await fetchValidTokens();
  const cleanToken = token.trim();
  const cleanTokens = validTokens.map(t => t.trim());
  return cleanTokens.includes(cleanToken);
}

async function startBot() {
  if (!BOT_TOKEN || BOT_TOKEN.trim() === '') {
    console.log(chalk.red('❌ BOT_TOKEN kosong! Isi di config.js'));
    process.exit(1);
  }

  console.log(chalk.blue('🔍 Validasi token ke GitHub...'));
  const isValid = await validateToken(BOT_TOKEN);

  if (!isValid) {
    console.log(chalk.red('❌ TOKEN TIDAK TERDAFTAR DI GITHUB!'));
    console.log(chalk.yellow('Pastikan BOT_TOKEN ada di token.json dan sama persis.'));
    process.exit(1);
  }

  console.log(chalk.blue('✅ Token valid! Menjalankan bot...'));
  const bot = new TelegramBot(BOT_TOKEN, { polling: true });
  runBot(bot);
}

// ========== DATABASE ==========
function loadDB() {
  if (!fs.existsSync(dbFile)) {
    fs.writeFileSync(dbFile, JSON.stringify({groups: {}}, null, 2));
  }
  return JSON.parse(fs.readFileSync(dbFile));
}
function saveDB(db) {
  fs.writeFileSync(dbFile, JSON.stringify(db, null, 2));
}

// Cek admin grup real-time
async function isGroupAdmin(bot, chatId, userId) {
  try {
    const member = await bot.getChatMember(chatId, userId);
    return member.status === "administrator" || member.status === "creator";
  } catch {
    return false;
  }
}

// Cari userId dari username
function findUserIdByUsername(chatId, username) {
  const db = loadDB();
  username = username.toLowerCase().replace("@", "");
  const members = db.groups[String(chatId)]?.members || {};
  for (let id in members) {
    if (members[id] === username) return id;
  }
  return null;
}

// Pesan khusus non-admin
const adminOnlyMsg = "⚠️ Fitur khusus admin grup\nLu bukan admin jadi gabisa akses command ini.";

// ========== BOT UTAMA ==========
function runBot(bot) {
  const usersFile = path.join(__dirname, "users.json");

  function getBotRuntime() {
    let uptime = process.uptime();
    let h = Math.floor(uptime / 3600);
    let m = Math.floor((uptime % 3600) / 60);
    let s = Math.floor(uptime % 60);
    return `${h}h ${m}m ${s}s`;
  }

  function getVideo() {
    return "https://files.catbox.moe/r3xvuo.mp4";
  }

  // Auto save user + username
  bot.on("message", (msg) => {
    if (!msg.from || msg.from.is_bot || msg.chat.type === "private") return;

    const db = loadDB();
    const chatId = String(msg.chat.id);
    const userId = String(msg.from.id);
    const username = msg.from.username? msg.from.username.toLowerCase() : null;

    if (!db.groups) db.groups = {};
    if (!db.groups[chatId]) {
      db.groups[chatId] = {members: {}, tag: {}, welcome: {status: false, text: ""}, left: {status: false, text: ""}, filter: {}};
    }

    db.groups[chatId].members[userId] = username;
    saveDB(db);

    let users = [];
    if (fs.existsSync(usersFile)) users = JSON.parse(fs.readFileSync(usersFile));
    if (!users.includes(msg.chat.id)) {
      users.push(msg.chat.id);
      fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
    }
  });

  async function getTargetUser(msg, match) {
    if (msg.reply_to_message) {
      return String(msg.reply_to_message.from.id);
    }
    if (match && match[1]) {
      const targetId = findUserIdByUsername(msg.chat.id, match[1]);
      return targetId;
    }
    return null;
  }

  function sendMenuAdmin(chatId) {
    const menuText = `<pre>━━━【𝕏terclose】━━━
╭▄︻ᴍᴇɴᴜ ᴀᴅᴍɪɴ═══━一
┃    オーナーメニュー
━━━【ᴀᴅᴍɪɴ】━━━
┃╰┈➤ /ban
┃ᝰ.ᐟ ban user
┃╰┈➤ /unban
┃ᝰ.ᐟ unban user
┃╰┈➤ /linkgb
┃ᝰ.ᐟ untuk memunculkan link gb
┃╰┈➤ /mute
┃ᝰ.ᐟ mute user
┃╰┈➤ /unmute
┃ᝰ.ᐟ unmute user
┃╰┈➤ /addadmin
┃ᝰ.ᐟ menambahkan akses admin groub
┃╰┈➤ /addadmin
┃ᝰ.ᐟ hapus akses admin di groub
╰━━━━━━━━━━━━━━━༉‧.</pre>`;

    const keyboard = {
      inline_keyboard: [
        [{ text: "Tools", callback_data: "x_spam", style: "danger" }],
        [{ text: "⬅️ Kembali", callback_data: "back_start", style: "danger" }]
      ]
    };
    bot.sendMessage(chatId, menuText, {parse_mode: "HTML", reply_markup: keyboard});
  }

  function sendMenuspam(chatId) {
    const menuText = `<pre>╔═════════════════════════
║ ⚡ S P A M  W H A T S A P ⚡                                 
║       XTERCLOSE TEAM             
║
║
║ ━━━【𝕏terclose】━━━
║ ╭▄︻デɮʟօƈƙ ƈʍɖ═══━一 
║ ┃╰┈➤ /addsender
║ ┃╰┈➤ /status 
║ ┃╰┈➤ /spam
║ ╰━━━━━━━━━━━━━━━༉‧       
╚═════════════════════════</pre>`;
    const keyboard = {
      inline_keyboard: [
        [{ text: "⬅️ Kembali", callback_data: "menu_admin", style: "danger" }]
      ]
    };
    bot.sendMessage(chatId, menuText, {parse_mode: "HTML", reply_markup: keyboard});
  }

  async function handleStart(chatId, username, senderId) {
    const runtime = getBotRuntime();
    const RandomVideo = getVideo();

    const keyboard = {
      inline_keyboard: [
        [{ text: "༺𓆩❟❛❟𓆪༻━【𝕏─𝕄𝔼ℕ𝕌─𝕏】━༺𓆩❟❛❟𓆪༻", callback_data: "menu_admin", style: "danger" }],
        [{ text: "༺𓆩❟❛❟𓆪༻━━༺𓆩❟❛❟𓆪༻", callback_data: "open_menu", style: "danger" }],
      ]
    };

    const caption = `<pre>
╭━━━━━━
┃ᝰ.ᐟ 所有者 : @xterclosexbunzz
┃ᝰ.ᐟ バージョン : Bot Xterclose
┃ᝰ.ᐟ ランタイム : ${runtime}
╰⋆━━━━━━━━━━༉‧.
༺𓆩❟❛❟𓆪༻⋆𝕏terclose⋆༺𓆩❟❛❟𓆪༻⋆
╭━( 𝕀𝕟𝕗𝕠𝕣𝕞𝕒𝕤𝕚 )
┃ᝰ.ᐟ ユーザー : ${username}
┃ᝰ.ᐟ ユーザーID : ${senderId}
╰━━━━━━━━━━༉‧.</pre>`;

    try {
      await bot.sendVideo(chatId, RandomVideo, {caption, parse_mode: "HTML", reply_markup: keyboard});
    } catch (err) {
      bot.sendMessage(chatId, "Gagal kirim video");
    }
  }

  bot.onText(/\/start/, async (msg) => {
    const username = msg.from.username? `@${msg.from.username}` : "Tidak ada username";
    await handleStart(msg.chat.id, username, msg.from.id);
  });

  bot.onText(/\/menuadmin/, async (msg) => {
    if (!(await isGroupAdmin(bot, msg.chat.id, msg.from.id))) return bot.sendMessage(msg.chat.id, adminOnlyMsg);
    sendMenuAdmin(msg.chat.id);
  });

  bot.onText(/\/tools/, async (msg) => {
    if (!(await isGroupAdmin(bot, msg.chat.id, msg.from.id))) return bot.sendMessage(msg.chat.id, adminOnlyMsg);
    sendMenuspam(msg.chat.id); // FIX: ganti tools_spam jadi sendMenuspam
  });

  // ========== COMMAND ADMIN GRUP ==========

  bot.onText(/\/linkgb/, async (msg) => {
    if (!(await isGroupAdmin(bot, msg.chat.id, msg.from.id))) return bot.sendMessage(msg.chat.id, adminOnlyMsg);
    if (msg.chat.type === "private") return bot.sendMessage(msg.chat.id, "❌ Command ini cuma di grup!");
    try {
      const link = await bot.exportChatInviteLink(msg.chat.id);
      bot.sendMessage(msg.chat.id, `🔗 <b>Link Grup:</b>\n<code>${link}</code>`, {parse_mode: "HTML"});
    } catch(e) {
      bot.sendMessage(msg.chat.id, "❌ Gagal ambil link");
    }
  });

  bot.onText(/\/ban(?:\s+@?([\w_]+))?/, async (msg, match) => {
    if (msg.chat.type === "private") return;
    if (!(await isGroupAdmin(bot, msg.chat.id, msg.from.id))) return bot.sendMessage(msg.chat.id, adminOnlyMsg);

    const targetId = await getTargetUser(msg, match);
    if (!targetId) return bot.sendMessage(msg.chat.id, "❌ Reply user atau /ban @username\nNote: User harus udah chat di grup ini 1x");

    if (await isGroupAdmin(bot, msg.chat.id, targetId)) return bot.sendMessage(msg.chat.id, "❌ Gabisa ban admin lain!");

    try {
      await bot.banChatMember(msg.chat.id, targetId);
      bot.sendMessage(msg.chat.id, `🚫 User berhasil di ban`, {parse_mode: "HTML"});
    } catch(e) {
      bot.sendMessage(msg.chat.id, "❌ Gagal ban. Bot harus admin + izin ban");
    }
  });

  bot.onText(/\/unban(?:\s+@?([\w_]+))?/, async (msg, match) => {
    if (msg.chat.type === "private") return;
    if (!(await isGroupAdmin(bot, msg.chat.id, msg.from.id))) return bot.sendMessage(msg.chat.id, adminOnlyMsg);

    const targetId = await getTargetUser(msg, match);
    if (!targetId) return bot.sendMessage(msg.chat.id, "❌ Reply user atau /unban @username");

    try {
      await bot.unbanChatMember(msg.chat.id, targetId);
      bot.sendMessage(msg.chat.id, `✅ User berhasil di unban`, {parse_mode: "HTML"});
    } catch(e) {
      bot.sendMessage(msg.chat.id, "❌ Gagal unban");
    }
  });

  bot.onText(/\/mute(?:\s+@?([\w_]+))?/, async (msg, match) => {
    if (msg.chat.type === "private") return;
    if (!(await isGroupAdmin(bot, msg.chat.id, msg.from.id))) return bot.sendMessage(msg.chat.id, adminOnlyMsg);

    const targetId = await getTargetUser(msg, match);
    if (!targetId) return bot.sendMessage(msg.chat.id, "❌ Reply user atau /mute @username");

    if (await isGroupAdmin(bot, msg.chat.id, targetId)) return bot.sendMessage(msg.chat.id, "❌ Gabisa mute admin!");

    try {
      await bot.restrictChatMember(msg.chat.id, targetId, {
        can_send_messages: false,
        can_send_media_messages: false,
        can_send_polls: false,
        can_send_other_messages: false
      });
      bot.sendMessage(msg.chat.id, `🔇 User di mute`, {parse_mode: "HTML"});
    } catch(e) {
      bot.sendMessage(msg.chat.id, "❌ Gagal mute");
    }
  });

  bot.onText(/\/unmute(?:\s+@?([\w_]+))?/, async (msg, match) => {
    if (msg.chat.type === "private") return;
    if (!(await isGroupAdmin(bot, msg.chat.id, msg.from.id))) return bot.sendMessage(msg.chat.id, adminOnlyMsg);

    const targetId = await getTargetUser(msg, match);
    if (!targetId) return bot.sendMessage(msg.chat.id, "❌ Reply user atau /unmute @username");

    try {
      await bot.restrictChatMember(msg.chat.id, targetId, {
        can_send_messages: true,
        can_send_media_messages: true,
        can_send_polls: true,
        can_send_other_messages: true
      });
      bot.sendMessage(msg.chat.id, `🔊 User di unmute`, {parse_mode: "HTML"});
    } catch(e) {
      bot.sendMessage(msg.chat.id, "❌ Gagal unmute");
    }
  });

  bot.onText(/\/addadmin(?:\s+@?([\w_]+))?/, async (msg, match) => {
    if (msg.chat.type === "private") return;
    if (!(await isGroupAdmin(bot, msg.chat.id, msg.from.id))) return bot.sendMessage(msg.chat.id, adminOnlyMsg);

    const targetId = await getTargetUser(msg, match);
    if (!targetId) return bot.sendMessage(msg.chat.id, "❌ Reply user atau /addadmin @username");

    try {
      await bot.promoteChatMember(msg.chat.id, targetId, {
        can_manage_chat: true,
        can_delete_messages: true,
        can_manage_video_chats: true,
        can_restrict_members: true,
        can_promote_members: false,
        can_change_info: true,
        can_invite_users: true
      });
      bot.sendMessage(msg.chat.id, `⬆️ User jadi admin`, {parse_mode: "HTML"});
    } catch(e) {
      bot.sendMessage(msg.chat.id, "❌ Gagal promote. Bot harus owner grup");
    }
  });

  bot.onText(/\/deladmin(?:\s+@?([\w_]+))?/, async (msg, match) => {
    if (msg.chat.type === "private") return;
    if (!(await isGroupAdmin(bot, msg.chat.id, msg.from.id))) return bot.sendMessage(msg.chat.id, adminOnlyMsg);

    const targetId = await getTargetUser(msg, match);
    if (!targetId) return bot.sendMessage(msg.chat.id, "❌ Reply admin atau /deladmin @username");

    try {
      await bot.promoteChatMember(msg.chat.id, targetId, {
        can_manage_chat: false,
        can_delete_messages: false,
        can_manage_video_chats: false,
        can_restrict_members: false,
        can_promote_members: false,
        can_change_info: false,
        can_invite_users: false
      });
      bot.sendMessage(msg.chat.id, `⬇️ User jadi member`, {parse_mode: "HTML"});
    } catch(e) {
      bot.sendMessage(msg.chat.id, "❌ Gagal demote");
    }
  });

  bot.onText(/\/open/, async (msg) => {
    if (!(await isGroupAdmin(bot, msg.chat.id, msg.from.id))) return bot.sendMessage(msg.chat.id, adminOnlyMsg);
    try {
      await bot.setChatPermissions(msg.chat.id, {can_send_messages: true});
      bot.sendMessage(msg.chat.id, "🔓 Grup dibuka");
    } catch(e) {
      bot.sendMessage(msg.chat.id, "❌ Gagal buka grup");
    }
  });

  bot.onText(/\/close/, async (msg) => {
    if (!(await isGroupAdmin(bot, msg.chat.id, msg.from.id))) return bot.sendMessage(msg.chat.id, adminOnlyMsg);
    try {
      await bot.setChatPermissions(msg.chat.id, {can_send_messages: false});
      bot.sendMessage(msg.chat.id, "🔒 Grup ditutup");
    } catch(e) {
      bot.sendMessage(msg.chat.id, "❌ Gagal tutup grup");
    }
  });

  // /id /info /ping bebas semua user
  bot.onText(/\/id/, (msg) => {
    const chatId = msg.chat.id;
    const replyMsg = msg.reply_to_message;
    if (replyMsg) {
      bot.sendMessage(chatId, `🆔 ID User: <code>${replyMsg.from.id}</code>\n🆔 ID Chat: <code>${chatId}</code>\n👤 Name: ${replyMsg.from.first_name}`, { parse_mode: "HTML" });
    } else {
      bot.sendMessage(chatId, `🆔 ID Kamu: <code>${msg.from.id}</code>\n🆔 ID Chat: <code>${chatId}</code>`, { parse_mode: "HTML" });
    }
  });

  bot.onText(/\/info/, async (msg) => {
    const chatId = msg.chat.id;
    const target = msg.reply_to_message? msg.reply_to_message.from : msg.from;
    const username = target.username? `${target.username}` : "Tidak ada username";
    const id = target.id;
    const text = `<blockquote>ID KAMU
×͜× Username : <code>${username}</code>
×͜× Id: <code>${id}</code>
×͜× Telegram Premium: ✖️
┗━━━━━━━━━━⬣
𝘾𝙍𝙀𝘼𝙏𝙀 𝘽𝙔 𝕏terclose:)</blockquote>`;
    bot.sendMessage(chatId, text, { parse_mode: "HTML" });
  });

  bot.onText(/\/ping/, async (msg) => {
    const chatId = msg.chat.id;
    const start = Date.now();
    const sent = await bot.sendMessage(chatId, "🔥...");
    const latency = Date.now() - start;
    bot.editMessageText(`🔥!\n⏱ Latency: ${latency}ms`, { chat_id: chatId, message_id: sent.message_id });
  });
  
  let sock;
  let waConnected = false;
  let connecting = false;

  let senderData = {
    number: null,
    connected: false,
    lastSeen: null
  };

  const delay = (ms) => new Promise(r => setTimeout(r, ms));
  const randomDelay = (min, max) => delay(Math.floor(Math.random() * (max - min + 1)) + min);

  async function startWA() {
    if (connecting) return;
    connecting = true;

    try {
        // Tutup socket lama
        if (sock) {
            try { sock.end(); } catch {}
            await delay(1000);
        }

        const { state, saveCreds } = await useMultiFileAuthState('./session');
        const { version } = await fetchLatestBaileysVersion();

        sock = makeWASocket({
            version,
            auth: {
                creds: state.creds,
                keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' }))
            },
            logger: pino({ level: 'silent' }),
            printQRInTerminal: false,
            browser: ['Ubuntu', 'Chrome', '120.0.0'],
            connectTimeoutMs: 60000,
            keepAliveIntervalMs: 30000,
            markOnlineOnConnect: false,
            syncFullHistory: false
        });

        sock.ev.on('creds.update', saveCreds);

        sock.ev.on('connection.update', (update) => {
            const { connection, lastDisconnect } = update;

            if (connection === 'close') {
                waConnected = false;
                connecting = false;
                const reason = lastDisconnect?.error?.output?.statusCode;
                console.log('WA Disconnected:', reason);

                if (reason!== DisconnectReason.loggedOut) {
                    console.log('Reconnecting in 5s...');
                    setTimeout(startWA, 5000);
                }
            }

            if (connection === 'connecting') {
                console.log('Connecting to WhatsApp...');
            }

            if (connection === 'open') {
                waConnected = true;
                connecting = false;
                console.log('✅ WA Connected!');
            }
        });
    } catch (err) {
        console.error('Error startWA:', err);
        connecting = false;
        setTimeout(startWA, 5000);
    }
}

  // Command /pair
  bot.onText(/\/addsender (.+)/, async (msg, match) => {
    if (msg.from.id!= OWNER_ID) return bot.sendMessage(msg.chat.id, 'Akses ditolak');
    const number = match[1].replace(/[^0-9]/g, '');
    if (!number) return bot.sendMessage(msg.chat.id, 'Format: addsender 628123456789');
    try {
      if (fs.existsSync('./session/creds.json')) {
        await bot.sendMessage(msg.chat.id, 'Hapus session lama...');
        fs.rmSync('./session', { recursive: true, force: true });
        await delay(2000);
      }
      await bot.sendMessage(msg.chat.id, 'Memulai koneksi ke WhatsApp...');
      await startWA();
      let tries = 0;
      while (!sock && tries < 15) {await delay(1000); tries++;}
      if (!sock) return bot.sendMessage(msg.chat.id, 'Gagal inisialisasi socket');
      await bot.sendMessage(msg.chat.id, 'Meminta pairing code...');
      await delay(2000);
      const code = await sock.requestPairingCode(number);
      if (!code) return bot.sendMessage(msg.chat.id, 'Gagal dapet code');
      const formattedCode = code.match(/.{1,4}/g)?.join('-');
      await bot.sendMessage(msg.chat.id, `*Kode Pairing:* \`${formattedCode}\`\n\nBuka WA > Setelan > Perangkat Tertaut`, { parse_mode: 'Markdown' });
    } catch (e) {
      bot.sendMessage(msg.chat.id, 'Error: ' + e.message);
      connecting = false;
    }
  });

  // Command /status - LENGKAP
  bot.onText(/\/status/, (msg) => {
    if (msg.from.id!= OWNER_ID) return;
    let statusText = `<blockquote>📡 STATUS WA SENDER</blockquote>\n`;
    statusText += `┏━━━━━━━━━━━━━━━\n`;
    statusText += `┃ Status: ${waConnected? '✅ Online' : '❌ Offline'}\n`;
    if (senderData.number) {
      statusText += `┃ Nomor: +${senderData.number}\n`;
    } else {
      statusText += `┃ Nomor: Belum di pair\n`;
    }
    statusText += `┃ Sender Aktif: ${waConnected? '1' : '0'}\n`;
    statusText += `┃ Last Seen: ${senderData.lastSeen || '-'}\n`;
    statusText += `┗━━━━━━━━━━━━━━━\n`;
    if (!waConnected) {
      statusText += `\n💡 Ketik /addsender 628xxx buat connect`;
    } else {
      statusText += `\n💡 Ketik /spam 628xxx|pesan|jumlah buat spam`;
    }
    bot.sendMessage(msg.chat.id, statusText, { parse_mode: "HTML" });
  });

  // Command /send
  bot.onText(/\/spam (.+)\|(.+)\|(\d+)/, async (msg, match) => {
    if (msg.from.id!= OWNER_ID) return;
    if (!waConnected) return bot.sendMessage(msg.chat.id, '❌ WhatsApp belum connect. Pakai /addsender dulu');
    const number = match[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    const text = match[2];
    const count = parseInt(match[3]);
    if (count <= 0 || count > 1000) return bot.sendMessage(msg.chat.id, '❌ Maksimal 1000 pesan');
    await bot.sendMessage(msg.chat.id, `Mulai kirim ${count}x ke ${match[1]}...`);
    let success = 0; let failed = 0;
    for (let i = 0; i < count; i++) {
      if (!waConnected) {await bot.sendMessage(msg.chat.id, '❌ Koneksi putus'); break;}
      try {
        await sock.sendMessage(number, { text: `${text}\n[${i + 1}/${count}]` });
        success++;
        if (i < count - 1) await randomDelay(0);
      } catch (e) {
        failed++;
        if (e.message.includes('rate-limited')) {await bot.sendMessage(msg.chat.id, '❌ Kena rate limit!'); break;}
        await delay(10000);
      }
    }
    await bot.sendMessage(msg.chat.id, `✅ Selesai!\nBerhasil: ${success}\nGagal: ${failed}`);
  });


  // Handler tombol - FIX: hapus switch dobel
  bot.on("callback_query", async (callbackQuery) => {
    const msg = callbackQuery.message;
    const data = callbackQuery.data;
    const chatId = msg.chat.id;
    const from = callbackQuery.from;

    try { await bot.answerCallbackQuery(callbackQuery.id); } catch(e) {}

    if (!(await isGroupAdmin(bot, chatId, from.id)) && data.startsWith("cmd_")) {
      return bot.answerCallbackQuery(callbackQuery.id, {text: "⚠️ Fitur khusus admin grup", show_alert: true});
    }

    switch (data) {
      case "menu_admin":
        try { await bot.deleteMessage(chatId, msg.message_id); } catch(e) {}
        sendMenuAdmin(chatId);
        break;

      case "back_start":
        try { await bot.deleteMessage(chatId, msg.message_id); } catch(e) {}
        const username = from.username? `@${from.username}` : "Tidak ada username";
        await handleStart(chatId, username, from.id);
        break;

      case "x_spam": // FIX: tambahin handler ini
        try { await bot.deleteMessage(chatId, msg.message_id); } catch(e) {}
        sendMenuspam(chatId);
        break;

    }
  });

  bot.on('polling_error', (err) => console.log(chalk.red(err.message)));

  bot.setMyCommands([
    { command: 'start', description: '🏠 Mulai bot' },
  ]).then(() => {
    console.log(chalk.blue('[BOT] Bot ready - Admin grup only ⚔️'));
  });
}

startBot();