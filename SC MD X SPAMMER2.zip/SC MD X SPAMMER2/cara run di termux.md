npm install
npm install pino
npm install @whiskeysockets/baileys
npm install chalk
npm install axios
npm install node-telegram-bot-api
npm i chalk@4.1.2
npm start